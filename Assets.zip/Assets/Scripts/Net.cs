using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Net : MonoBehaviour
{
    public float speed = 10.0f;
    public BoxCollider2D bc;
    public Rigidbody2D rb;
    public Text ScoreText;
    public int ScoreCount;
    // Start is called before the first frame update
    void Start()
    {
        bc = gameObject.AddComponent<BoxCollider2D>() as BoxCollider2D;
        bc.isTrigger = true;

        rb = gameObject.AddComponent<Rigidbody2D>() as Rigidbody2D;
        rb.bodyType = RigidbodyType2D.Kinematic;  
    }

    // Update is called once per frame
    void Update()
    {
     if (Input.GetKey(KeyCode.LeftArrow))
         {
             transform.position += Vector3.left * speed * Time.deltaTime;
         }
         if (Input.GetKey(KeyCode.RightArrow))
         {
             transform.position += Vector3.right * speed * Time.deltaTime;
         }
         if (Input.GetKey(KeyCode.UpArrow))
         {
             transform.position += Vector3.up * speed * Time.deltaTime;
         }
         if (Input.GetKey(KeyCode.DownArrow))
         {
             transform.position += Vector3.down * speed * Time.deltaTime;
         }    
    }

     void OnTriggerEnter(Collider col)
    {
     if(col.GetComponent<Collider>().name == "Fish")
     {
         ScoreCount++;
     }
     else if(col.GetComponent<Collider>().name == "Bomb")
     {
         ScoreCount--;
     }
    }  

}
