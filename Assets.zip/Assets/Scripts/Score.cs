using UnityEngine;
using System.Collections;
using UnityEngine.UI;
 
public class Score : MonoBehaviour {
 
 
 
    public Text ScoreText;
    public int ScoreCount;
 
 
    // Use this for initialization
    void Start () {
        ScoreCount = 0;
    }
 
 
    // Update is called once per frame
    void Update () {
   
      // ScoreCount = ScoreCount.GetInt(ScoreCount, 0);
     //  ScoreText.Text = "Score", Score.ToString();
 
    }
 
 
    void AddScore(Collider coll) {
 
        ScoreCount = ScoreCount + 1;
 
    }
 
 
}